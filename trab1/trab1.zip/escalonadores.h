#define MAX_PROG 10 
void round_robin(char * programas[MAX_PROG], int n);
void prioridades(char * programas[MAX_PROG], int prioridades[MAX_PROG], int n);